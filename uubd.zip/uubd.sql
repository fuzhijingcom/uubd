-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2019-02-26 15:57:22
-- 服务器版本： 5.5.56-log
-- PHP 版本： 7.1.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `uubd`
--

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_ad`
--

CREATE TABLE `g2ex_ad` (
  `id` smallint(6) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL,
  `expires` date NOT NULL,
  `location` tinyint(1) UNSIGNED NOT NULL,
  `invisible` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `node_id` smallint(6) UNSIGNED NOT NULL DEFAULT '1',
  `sortid` tinyint(1) UNSIGNED NOT NULL DEFAULT '50',
  `name` varchar(20) NOT NULL,
  `content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_auth`
--

CREATE TABLE `g2ex_auth` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `user_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `source` varchar(20) NOT NULL,
  `source_id` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_auth`
--

INSERT INTO `g2ex_auth` (`id`, `user_id`, `source`, `source_id`) VALUES
(1, 1, 'xcx', 'abc'),
(2, 4, 'xcx', 'oPZzW5dVNTRv5xQQrasoDt65fYgA'),
(3, 5, 'xcx', 'oPZzW5d1bpRhXRIes7LtsPH1nkNY'),
(4, 6, 'xcx', 'oPZzW5XajzjXNu6LVDnIoM54FA5I'),
(5, 7, 'xcx', 'oPZzW5QYWbo-TCJmW7viAnZdT1mA'),
(6, 8, 'xcx', 'oPZzW5SIYpHOdWzapeiK4aeeDRpY'),
(7, 9, 'xcx', 'oPZzW5f5a75k30y3Df6UpyPksKkE');

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_comment`
--

CREATE TABLE `g2ex_comment` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL,
  `updated_at` int(10) UNSIGNED NOT NULL,
  `user_id` mediumint(8) UNSIGNED NOT NULL,
  `topic_id` mediumint(8) UNSIGNED NOT NULL,
  `position` mediumint(8) UNSIGNED NOT NULL,
  `invisible` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `good` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `vote_count` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_comment`
--

INSERT INTO `g2ex_comment` (`id`, `created_at`, `updated_at`, `user_id`, `topic_id`, `position`, `invisible`, `good`, `vote_count`, `content`) VALUES
(1, 1530082943, 1530082943, 1, 3, 1, 0, 0, 0, '不错啊');

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_commentid`
--

CREATE TABLE `g2ex_commentid` (
  `id` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_commentid`
--

INSERT INTO `g2ex_commentid` (`id`) VALUES
(1);

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_favorite`
--

CREATE TABLE `g2ex_favorite` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `source_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `target_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_favorite`
--

INSERT INTO `g2ex_favorite` (`id`, `type`, `source_id`, `target_id`) VALUES
(1, 2, 1, 3);

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_history`
--

CREATE TABLE `g2ex_history` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `type` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `action` tinyint(1) UNSIGNED NOT NULL,
  `action_time` int(10) UNSIGNED NOT NULL,
  `target` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `ext` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_history`
--

INSERT INTO `g2ex_history` (`id`, `user_id`, `type`, `action`, `action_time`, `target`, `ext`) VALUES
(1, 1, 1, 1, 1528268384, 1900144371, '{\"score\":10000000,\"cost\":100}'),
(2, 1, 0, 2, 1530080639, 992566512, ''),
(3, 1, 1, 20, 1530080781, 1, '{\"topic_id\":1,\"title\":\"ajax+jsonp+php \\u5b9e\\u73b0\\u8de8\\u57df\\u4ea4\\u6362\\u6570\\u636e\",\"score\":9999980,\"cost\":-20}'),
(4, 1, 1, 30, 1530080970, 0, '{\"score\":10000980,\"cost\":1000}'),
(5, 1, 1, 31, 1530081665, 0, '{\"score\":10000996,\"cost\":16,\"continue\":1}'),
(6, 2, 1, 1, 1530082386, 992566512, '{\"score\":100,\"cost\":100}'),
(7, 2, 1, 20, 1530082780, 3, '{\"topic_id\":3,\"title\":\"\\u7a0b\\u5e8f\\u5458\\u9ad8\\u624b\\u7684\\u8f6f\\u5b9e\\u529b\",\"score\":80,\"cost\":-20}'),
(8, 2, 1, 37, 1530082818, 0, '{\"thank_by\":\"admin\",\"score\":100,\"cost\":20,\"topic_id\":3,\"title\":\"\\u7a0b\\u5e8f\\u5458\\u9ad8\\u624b\\u7684\\u8f6f\\u5b9e\\u529b\"}'),
(9, 1, 1, 24, 1530082818, 3, '{\"thank_to\":\"\\u4e00\\u5230\\u516d\",\"score\":10000976,\"cost\":-20,\"topic_id\":3,\"title\":\"\\u7a0b\\u5e8f\\u5458\\u9ad8\\u624b\\u7684\\u8f6f\\u5b9e\\u529b\"}'),
(10, 2, 1, 36, 1530082943, 3, '{\"topic_id\":3,\"title\":\"\\u7a0b\\u5e8f\\u5458\\u9ad8\\u624b\\u7684\\u8f6f\\u5b9e\\u529b\",\"commented_by\":\"admin\",\"score\":105,\"cost\":5}'),
(11, 1, 1, 22, 1530082943, 1, '{\"topic_id\":3,\"title\":\"\\u7a0b\\u5e8f\\u5458\\u9ad8\\u624b\\u7684\\u8f6f\\u5b9e\\u529b\",\"score\":10000971,\"cost\":-5}'),
(12, 2, 1, 30, 1530083039, 0, '{\"score\":1105,\"cost\":1000}'),
(13, 1, 1, 31, 1530151268, 0, '{\"score\":10001018,\"cost\":47,\"continue\":2}'),
(14, 1, 1, 20, 1530168757, 4, '{\"topic_id\":4,\"title\":\"php artisan key:generate\",\"score\":10000998,\"cost\":-20}'),
(15, 1, 1, 20, 1530170609, 5, '{\"topic_id\":5,\"title\":\"\\u89e3\\u51b3 1071 Specified key was too long\",\"score\":10000978,\"cost\":-20}'),
(16, 1, 0, 21, 1530170683, 5, ''),
(17, 1, 0, 21, 1530170840, 5, ''),
(18, 1, 0, 2, 1530281654, 1947536649, ''),
(19, 2, 0, 2, 1530286362, 1947536649, ''),
(20, 1, 1, 20, 1530424808, 6, '{\"topic_id\":6,\"title\":\"git rm\\u4e0egit rm --cached\",\"score\":10000958,\"cost\":-20}'),
(21, 2, 0, 2, 1530425632, 992668917, ''),
(22, 1, 1, 31, 1530426032, 0, '{\"score\":10001004,\"cost\":46,\"continue\":1}'),
(23, 2, 1, 31, 1530455153, 0, '{\"score\":1142,\"cost\":37,\"continue\":1}'),
(24, 1, 0, 2, 1530786505, 1900143682, ''),
(25, 1, 1, 20, 1530796703, 7, '{\"topic_id\":7,\"title\":\"\\u5173\\u4e8e\\u7f51\\u8d37\\u6587\\u7ae0 \\u5f53\\u91d1\\u878d\\u9047\\u5230\\u4e92\\u8054\\u7f51\",\"score\":10000984,\"cost\":-20}'),
(26, 1, 1, 20, 1531028948, 8, '{\"topic_id\":8,\"title\":\"\\u54c8\\u54c8\\u54c8\\u54c8\",\"score\":10000964,\"cost\":-20}'),
(27, 1, 0, 21, 1531048286, 8, ''),
(28, 1, 0, 21, 1531149743, 8, ''),
(29, 3, 1, 1, 1531378032, 1974720148, '{\"score\":100,\"cost\":100}'),
(30, 1, 1, 20, 1532322455, 9, '{\"topic_id\":9,\"title\":\"\\u6570\\u636e\\u5b89\\u5168\\u5927\\u4e8e\\u4e00\\u5207\\uff0c\\u4eca\\u5929\\u4f60\\u628a\\u81ea\\u5df1\\u5907\\u4efd\\u4e86\\u5417\\uff1f\",\"score\":10000944,\"cost\":-20}'),
(31, 1, 0, 21, 1532322506, 9, ''),
(32, 1, 0, 21, 1532322786, 9, ''),
(33, 1, 0, 2, 1533364963, 1947537151, ''),
(34, 1, 1, 20, 1533365059, 10, '{\"topic_id\":10,\"title\":\"NUXT\\uff08VUE SSR \\u670d\\u52a1\\u7aef\\u6e32\\u67d3\\uff09\",\"score\":10000924,\"cost\":-20}'),
(35, 10, 1, 1, 1535439375, 986737834, '{\"score\":100,\"cost\":100}'),
(36, 10, 1, 20, 1535439394, 11, '{\"topic_id\":11,\"title\":\"\\u82cf\\u5dde\\u80a1\\u7968\\u914d\\u8d44\",\"score\":80,\"cost\":-20}'),
(37, 1, 0, 2, 1535531001, 1039280680, ''),
(38, 1, 0, 21, 1535531010, 11, ''),
(39, 1, 0, 21, 1535531032, 11, ''),
(40, 11, 1, 1, 1545533603, 3000350775, '{\"score\":100,\"cost\":100}');

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_link`
--

CREATE TABLE `g2ex_link` (
  `id` smallint(6) UNSIGNED NOT NULL,
  `sortid` tinyint(1) UNSIGNED NOT NULL DEFAULT '50',
  `name` varchar(20) NOT NULL,
  `url` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_link`
--

INSERT INTO `g2ex_link` (`id`, `sortid`, `name`, `url`) VALUES
(1, 0, '极简论坛', 'http://simpleforum.org/'),
(2, 0, 'G2EX', 'http://g2ex.com');

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_msg`
--

CREATE TABLE `g2ex_msg` (
  `id` int(11) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `code` varchar(10) NOT NULL,
  `msg` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_msg`
--

INSERT INTO `g2ex_msg` (`id`, `mobile`, `code`, `msg`, `status`, `time`) VALUES
(1, '13516565558', '8643', 'OK', 'OK', 1531675866),
(2, '18665875575', '8392', 'OK', 'OK', 1531677739),
(3, '13729069054', '2360', 'OK', 'OK', 1531751006),
(4, '13729069054', '1612', 'OK', 'OK', 1531751256),
(5, '13729069054', '7715', 'OK', 'OK', 1531751461),
(6, '13729069054', '2320', 'OK', 'OK', 1531752622),
(7, '13729069054', '9515', 'OK', 'OK', 1531831336),
(8, '13516565558', '2409', 'OK', 'OK', 1531831955),
(9, '13157604182', '3390', 'OK', 'OK', 1532232799),
(10, '13342779637', '2229', 'OK', 'OK', 1532315180),
(11, '13600387110', '3175', 'OK', 'OK', 1532341107),
(12, '13602714234', '3569', 'OK', 'OK', 1533360863),
(13, '13602714234', '5945', 'OK', 'OK', 1533361132),
(14, '13602714234', '1822', '触发分钟级流控Permits:1', 'isv.BUSINESS_LIMIT_CONTROL', 1533361133),
(15, '13602714234', '8607', 'OK', 'OK', 1533362611),
(16, '13602714234', '4235', 'OK', 'OK', 1533365759),
(17, '13602714234', '2358', '触发分钟级流控Permits:1', 'isv.BUSINESS_LIMIT_CONTROL', 1533365760);

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_navi`
--

CREATE TABLE `g2ex_navi` (
  `id` smallint(6) UNSIGNED NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `sortid` tinyint(1) UNSIGNED NOT NULL DEFAULT '50',
  `name` varchar(20) NOT NULL,
  `ename` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_navi_node`
--

CREATE TABLE `g2ex_navi_node` (
  `id` int(10) UNSIGNED NOT NULL,
  `navi_id` smallint(6) UNSIGNED NOT NULL,
  `node_id` smallint(6) UNSIGNED NOT NULL,
  `visible` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `sortid` tinyint(1) UNSIGNED NOT NULL DEFAULT '50'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_node`
--

CREATE TABLE `g2ex_node` (
  `id` smallint(6) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL,
  `updated_at` int(10) UNSIGNED NOT NULL,
  `topic_count` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `favorite_count` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `access_auth` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `invisible` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(20) NOT NULL,
  `ename` varchar(20) NOT NULL,
  `about` varchar(255) NOT NULL DEFAULT '',
  `index` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `icon` char(100) NOT NULL DEFAULT 'static/node/default.png',
  `image` text NOT NULL,
  `editor` varchar(20) NOT NULL DEFAULT 'SmdEditor'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_node`
--

INSERT INTO `g2ex_node` (`id`, `created_at`, `updated_at`, `topic_count`, `favorite_count`, `access_auth`, `invisible`, `name`, `ename`, `about`, `index`, `icon`, `image`, `editor`) VALUES
(1, 1528268364, 1528268364, 3, 0, 0, 0, '默认分类', 'default', '默认的节点', 0, 'static/node/default.png', '', 'SmdEditor'),
(2, 1530168606, 1530168606, 2, 0, 0, 0, 'Laravel', 'laravel', '流行PHP框架', 1, 'static/node/laravel.jpg', '', 'SmdEditor'),
(3, 1530424668, 1530424685, 1, 0, 0, 0, 'Git', 'git', '代码管理工具', 0, 'static/node/git.jpg', '', 'WysibbEditor'),
(4, 1530502885, 1530502885, 1, 0, 0, 0, 'NUXT', 'nuxt', '', 0, 'static/node/nuxt.jpg', '', 'SmdEditor'),
(5, 1530790177, 1530790177, 3, 0, 0, 0, '金融', 'finance', '', 0, 'static/node/bbs/bbs-jr.png', '', 'SmdEditor'),
(6, 1530790242, 1530790242, 0, 0, 0, 0, '居民服务', 'service', '', 0, 'static/node/bbs/bbs-jm.png', '', 'SmdEditor'),
(7, 1530790280, 1530790280, 0, 0, 0, 0, '制造', 'manufacture', '', 0, 'static/node/bbs/bbs-zz.png', '', 'SmdEditor'),
(8, 1530790313, 1530790313, 0, 0, 0, 0, '其他', 'other', '', 0, 'static/node/bbs/bbs-qt.png', '', 'SmdEditor'),
(9, 1530790393, 1530790393, 0, 0, 0, 0, '房地产', 'realestate', '', 0, 'static/node/bbs/bbs-fdc.png', '', 'SmdEditor'),
(10, 1530796061, 1530796061, 0, 0, 0, 0, '出租', 'lease', '', 0, 'static/node/bbs/bbs-zl.png', '', 'SmdEditor'),
(11, 1530796091, 1530796091, 0, 0, 0, 0, '建筑', 'architecture', '', 0, 'static/node/bbs/bbs-jz.png', '', 'SmdEditor');

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_notice`
--

CREATE TABLE `g2ex_notice` (
  `id` int(10) NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL,
  `updated_at` int(10) UNSIGNED NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `target_id` mediumint(8) UNSIGNED NOT NULL,
  `source_id` mediumint(8) UNSIGNED NOT NULL,
  `topic_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `position` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `notice_count` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `msg` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_notice`
--

INSERT INTO `g2ex_notice` (`id`, `created_at`, `updated_at`, `type`, `status`, `target_id`, `source_id`, `topic_id`, `position`, `notice_count`, `msg`) VALUES
(1, 1530082818, 1530083019, 7, 1, 2, 1, 3, 0, 0, ''),
(2, 1530082822, 1530083019, 3, 1, 2, 1, 3, 0, 0, ''),
(3, 1530082943, 1530083019, 1, 1, 2, 1, 3, 1, 0, '');

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_page`
--

CREATE TABLE `g2ex_page` (
  `id` smallint(6) UNSIGNED NOT NULL,
  `sortid` tinyint(1) UNSIGNED NOT NULL DEFAULT '50',
  `name` varchar(20) NOT NULL,
  `ename` varchar(20) NOT NULL,
  `url` varchar(100) NOT NULL,
  `content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_plugin`
--

CREATE TABLE `g2ex_plugin` (
  `id` smallint(6) UNSIGNED NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `pid` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `author` varchar(20) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `version` varchar(10) NOT NULL DEFAULT '',
  `config` text NOT NULL,
  `settings` text NOT NULL,
  `events` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_plugin`
--

INSERT INTO `g2ex_plugin` (`id`, `status`, `pid`, `name`, `description`, `author`, `url`, `version`, `config`, `settings`, `events`) VALUES
(1, 0, 'WysibbEditor', 'Wysibb编辑器(BBcode)', 'Wysibb编辑器(BBcode)', 'SimpleForum', 'http://simpleforum.org', '1.0', '', '', ''),
(2, 0, 'SmdEditor', 'Simple Markdown编辑器', 'Simple Markdown编辑器', 'SimpleForum', 'http://simpleforum.org', '1.0', '', '', ''),
(3, 0, 'KeywordFilter', '关键字过滤', '违规词过滤', 'SimpleForum', 'http://simpleforum.org', '1.0', '[{\"label\":\"\\u8fc7\\u6ee4\\u5173\\u952e\\u5b57\",\"key\":\"keywords\",\"type\":\"textarea\",\"value_type\":\"text\",\"value\":\"\",\"description\":\"\\u4e00\\u884c\\u4e00\\u4e2a\\u8fc7\\u6ee4\\u8bcd\"}]', '{\"keywords\":\"\\u6027\\u5427\\r\\n\\u8f6e\\u5978\\r\\n\\u809b\\u4ea4\\r\\n\\u88f8\\u804a\\r\\n\\u8ff7\\u5978\\r\\n\\u6deb\\u6c34\\r\\n\\u62bd\\u63d2\\r\\n\\u624b\\u673a\\u5bc6\\u7801\\u7834\\r\\n\\u6deb\\u59bb\\r\\n\\u731b\\u63d2\\r\\n\\u7a74\\u7a74\\r\\n\\u8214\\u9634\\r\\n\\u79c1\\u670d\\r\\n\\u76d1\\u542c\\r\\n\\u6210\\u4eba\\u7535\\u5f71\\r\\n\\u6210\\u4eba\\u5c0f\\u8bf4\\r\\n\\u5f3a\\u5978\\r\\n\\u5c0f\\u7a74\\r\\n\\u67aa\\u5305\\r\\n\\u9ec4\\u8272\\u4e66\\u520a\\r\\n\\u9ec4\\u8272\\u7535\\u5f71\\r\\n\\u9ec4\\u8272\\u5c0f\\u8bf4\\r\\n\\u4e8c\\u5976\\r\\n\\u4e00\\u591c\\u60c5\\r\\n\\u591a\\u591c\\u60c5\\r\\n\\u901a\\u8bdd\\u8bb0\\u5f55\\u67e5\\u8be2\\r\\n\\u517c\\u804c\\u59b9\\u59b9\\r\\n\\u517c\\u804c\\u7f8e\\u5973\\r\\n\\u67aa\\u652f\\r\\n\\u624b\\u67aa\\r\\n\\u5b50\\u5f39\\r\\n\\u6bd2\\u54c1\\r\\nK\\u7c89\\r\\n\\u88f8\\u4f53\\r\\n\\u55e8\\u836f\\r\\n\\u4e09\\u632b\\u4ed1\\r\\n\\u4e09\\u5511\\u4ed1\\r\\n\\u4ee3\\u8003\\r\\n\\u66ff\\u8003\\r\\n\\u8003\\u8bd5\\u7b54\\u6848\\r\\n\\u53d1\\u7968\\r\\n\\u4ee3\\u5f00\\r\\n\\u4ee3\\u529e\\r\\n\\u4ee3\\u6ce8\\r\\n\\u589e\\u503c\\u7a0e\\r\\n\\u5047\\u5e01\\r\\n\\u5047\\u94b1\\r\\n\\u5904\\u5973\\u5730\\r\\n\\u53e3\\u4ea4\\r\\n\\u6027\\u4ea4\\r\\n\\u505a\\u7231\\r\\n\\u88f8\\u7167\\r\\n\\u767c\\u7968\\r\\n\\u653f\\u5e9c\\u5b98\\u5458\\r\\n\\u79fb\\u52a8\\u901a\\u8bdd\\u6e05\\u5355\\r\\n\\u8054\\u901a\\u901a\\u8bdd\\u6e05\\u5355\\r\\n\\u5c0f\\u7075\\u901a\\u901a\\u8bdd\\u6e05\\u5355\\r\\n\\u5ea7\\u673a\\u901a\\u8bdd\\u6e05\\u5355\\r\\n\\u670d\\u52a1\\u5bc6\\u7801\\u5b9a\\u4f4d\\r\\n\\u5bc6\\u7801\\u7834\\u89e3\\r\\n\\u673a\\u4e0a\\u5206\\u5668\\r\\n\\u4e0a\\u6d77\\u8d70\\u79c1\\r\\n\\u65e0\\u7801\\r\\n\\u5185\\u5c04\\r\\n\\u7fa4\\u4f53\\u4e8b\\u4ef6\\r\\n\\u8bc1\\u4e66\\u529e\\u7406\\r\\n\\u8bc1\\u4ef6\\u529e\\u7406\\r\\n\\u7687\\u51a0\\u5f00\\u6237\\r\\n\\u542c\\u5668\\r\\n\\u6267\\u4e1a\\u533b\\u5e08\\r\\n\\u4ee3\\u7406\\u7533\\u62a5\\u804c\\u79f0\\r\\n\\u7acb\\u4fe1\\u4ee3\\u7406\\r\\n\\u590d\\u5236\\u624b\\u673a\\r\\n\\u7687\\u51a0\\u570b\\u969b\\r\\n\\u8d44\\u683c\\u8bc1\\u4e66\\r\\n\\u529e\\u7406\\u771f\\u5b9e\\r\\n\\u60c5\\u611f\\u966a\\u62a4\\r\\n\\u7fa4\\u4f53\\u6d41\\u8840\\r\\n\\u7a0e\\u52a1\\u516c\\u53f8\\r\\n\\u5404\\u79cdZJ\\r\\n\\u6027\\u7231\\r\\n\\u4ee3\\u7406\\u5ba1\\u62a5\\r\\n\\u8d22\\u7a0e\\u6709\\u9650\\r\\n\\u7f8e\\u5973\\u62a4\\u966a\\r\\n\\u4ee3\\u7406\\u62a5\\u5173\\r\\n\\u75c5\\u6bd2\\u8425\\u9500\\r\\n\\u9999\\u70df\\u6279\\u53d1\\r\\n\\u5973\\u5b69\\u4e0a\\u95e8\\r\\n\\u7f8e\\u5973\\u8131\\u8863\\r\\n\\u4f20\\u5947sf\\r\\n\\u6d41\\u8840\\u4e8b\\u4ef6\\r\\n\\u529e\\u8bc1\\r\\n\\u8d22\\u7a0e\\u4ee3\\u7406\\r\\n\\u4e13\\u4e1a\\u7a0e\\u52a1\\r\\n\\u59b9\\u7684\\u670d\\u52a1\\r\\n\\u7f8e\\u5973\\u4e0a\\u95e8\\r\\n\\u5973\\u4e0a\\u95e8\\r\\n\\u67e5\\u624b\\u673a\\r\\n\\u5927\\u6e38\\u884c\\r\\nAV\\u5973\\r\\n\\u5317\\u4eac\\u5f02\\r\\n\\u5317\\u4eac\\u6d0b\\u599e\\r\\n\\u536b\\u661f\\u8ffd\\u8e2a\\r\\n\\u53f7\\u7801\\u5b9a\\u4f4d\\r\\n\\u7f8e\\u5973\\u6309\\u6469\\r\\n\\u7f8e\\u5973\\u517c\\u804c\\r\\n\\u5357\\u4eac630\\r\\n630\\u8f66\\u7978\\r\\n\\u7fa4\\u4f53\\u6027\\u4e8b\\u4ef6\\r\\n\\u730e\\u67aa\\r\\n\\u519b\\u7528\\u624b\\r\\n\\u624b\\u67aa\\r\\n\\u7f8e\\u56fd\\u79c3\\u9e70\\r\\n\\u5355\\u53cc\\u7ba1\\u730e\\r\\n\\u8ff7\\u60c5\\r\\n\\u8ff7\\u9b42\\r\\n\\u653f\\u5e9c\\u9886\\u5bfc\\r\\n\\u6bdb\\u6cfd\\u4e1c\\u590d\\u6d3b\\r\\n\\u4e2d\\u5c71\\u9886\\u5bfc\\r\\n\\u6bdb\\u4e3b\\u5e2d\\u590d\\u6d3b\\r\\n27\\u519b\\r\\n\\u514b\\u9686\\u624b\\u673a\\r\\n\\u5356\\u6deb\\r\\n\\u4e94\\u56db\\u8fd0\\u52a8\\r\\n\\u516d\\u56db\\u8fd0\\u52a8\\r\\n54\\u8fd0\\u52a8\\r\\n64\\u8fd0\\u52a8\\r\\n\\u81ea\\u7531\\u95e8\\r\\n\\u8273\\u7167\\u95e8\\r\\n\\u8273\\u95e8\\u7167\\r\\n\\u8d4c\\u535a\\r\\n\\u8001\\u5a46\\u6bd4\\u5212\\u8001\\u516c\\u731c\\r\\n\\u674e\\u548f\\u90fd\\u7b11\\u8db4\\u4e0b\\r\\n\\u6253\\u4eba\\u4e8b\\u4ef6\\r\\n\\u672c\\u94a2\\u9886\\u5bfc\\r\\n\\u67aa\\u51fa\\u552e\\r\\n\\u7406\\u771f\\u6bd5\\u4e1a\\r\\n\\u8d44\\u683c\\u6b63\\r\\n\\u4e09\\u966a\\u5973\\u81ea\\u5f3a\\u6b4c\\r\\n\\u4e09\\u966a\\u5973\\r\\n\\u591f\\u683c\\u5f53\\u9886\\u5bfc\\r\\n\\u8003\\u8bd5\\u4ee3\\r\\n\\u9886\\u5bfc\\u7a77\\u5149\\u86cb\\r\\n\\u9886\\u5bfc\\u8d2a\\u6c61\\u72af\"}', '{\"afterParse\":\"keywordFilter\"}'),
(4, 0, 'QiniuUpload', '七牛上传', '将文件上传到七牛云', 'SimpleForum', 'http://simpleforum.org/', '1.0', '[{\"label\":\"\\u7a7a\\u95f4\\u540d\",\"key\":\"bucketName\",\"type\":\"text\",\"value_type\":\"text\",\"value\":\"\",\"description\":\"\"},{\"label\":\"access key\",\"key\":\"accessKey\",\"type\":\"text\",\"value_type\":\"text\",\"value\":\"\",\"description\":\"\"},{\"label\":\"secret key\",\"key\":\"secretKey\",\"type\":\"text\",\"value_type\":\"text\",\"value\":\"\",\"description\":\"\"},{\"label\":\"\\u7a7a\\u95f4URL\",\"key\":\"url\",\"type\":\"text\",\"value_type\":\"text\",\"value\":\"\",\"description\":\"\"}]', '{\"bucketName\":\"\",\"accessKey\":\"\",\"secretKey\":\"\",\"url\":\"\"}', '');

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_setting`
--

CREATE TABLE `g2ex_setting` (
  `id` smallint(6) UNSIGNED NOT NULL,
  `sortid` tinyint(1) UNSIGNED NOT NULL DEFAULT '50',
  `block` varchar(10) NOT NULL DEFAULT '',
  `label` varchar(50) NOT NULL DEFAULT '',
  `type` varchar(10) NOT NULL DEFAULT 'text',
  `key` varchar(50) NOT NULL,
  `value_type` varchar(10) NOT NULL DEFAULT 'text',
  `value` text NOT NULL,
  `option` text NOT NULL,
  `description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_setting`
--

INSERT INTO `g2ex_setting` (`id`, `sortid`, `block`, `label`, `type`, `key`, `value_type`, `value`, `option`, `description`) VALUES
(1, 1, 'info', '网站名称', 'text', 'site_name', 'text', 'UUBD', '', '考虑到手机浏览，网站名称不要设置过长。'),
(2, 2, 'info', '网站副标题', 'text', 'slogan', 'text', '这是一个学习、探索技术的微社区。', '', '15字以内'),
(3, 3, 'info', '网站描述', 'textarea', 'description', 'text', '广州琅百广告有限公司', '', '给搜索引擎看的，150字以内'),
(4, 4, 'info', '备案号', 'text', 'icp', 'text', '粤ICP备17111635号-5', '', '若有就填，如 京ICP证0603xx号'),
(5, 5, 'info', '管理员邮箱', 'text', 'admin_email', 'text', '', '', '用来接收用户错误报告'),
(6, 1, 'manage', '网站暂时关闭', 'select', 'offline', 'integer', '0', '[\"0(开启)\",\"1(关闭)\"]', '默认:0(开启)'),
(7, 2, 'manage', '网站暂时关闭提示', 'textarea', 'offline_msg', 'text', '网站维护中，请稍后访问', '', '简单写明关闭原因'),
(8, 3, 'manage', '只允许登录访问', 'select', 'access_auth', 'integer', '0', '[\"0(公开)\",\"1(登录访问)\"]', '默认0（公开），若规定登录用户才能访问就设为1（适合内部交流）'),
(9, 4, 'manage', '注册需邮箱验证', 'select', 'email_verify', 'integer', '0', '[\"0(关闭验证)\",\"1(开启验证)\"]', '建议设为1（需验证），若不需要验证就设为0'),
(10, 5, 'manage', '注册需管理员验证', 'select', 'admin_verify', 'integer', '0', '[\"0(关闭验证)\",\"1(开启验证)\"]', '默认0（不用验证），若需要管理员验证就设为1（适合内部交流）'),
(11, 6, 'manage', '关闭用户注册', 'select', 'close_register', 'integer', '0', '[\"0(开启注册)\",\"1(关闭注册)\",\"2(只开放邀请码注册)\"]', '默认0，若停止新用户注册就设为1（仍旧可以通过第三方帐号登录方式注册）'),
(12, 7, 'manage', '过滤用户名', 'text', 'username_filter', 'text', '', '', '指定用户名不能含有某些指定词汇，用半角逗号(,)分割，例：<br />admin,webmaster,admin*'),
(13, 8, 'manage', '开启验证码', 'select', 'captcha_enabled', 'integer', '0', '[\"0(关闭)\",\"1(开启)\"]', '开启后，注册和登录时会要求输入验证码'),
(14, 9, 'manage', '开启自动链接', 'select', 'autolink', 'integer', '0', '[\"0(关闭)\",\"1(开启)\"]', '自动给帖子内容中的网址加上链接'),
(15, 10, 'manage', '自动链接排除列表', 'textarea', 'autolink_filter', 'text', '', '[\"0(关闭\",\"1(开启)\"]', '不包含http://，可设置主域名或二级域名等，一行一个网址'),
(16, 11, 'manage', '模板', 'text', 'theme', 'text', 'g2ex', '', '模板名请用字母数字横杠下划线命名，模板放在\"themes/模板名/\"目录下'),
(17, 12, 'manage', '移动模板', 'text', 'theme_mobile', 'text', 'mobile', '', '移动设备（手机/平板）专用模板，模板名请用字母数字横杠下划线命名，放在\"themes/移动模板名/\"目录下'),
(18, 13, 'manage', '会员组', 'textarea', 'groups', 'text', '1500 普通会员\n3000 铜牌会员\n5000 银牌会员\n8000 金牌会员\n15000 铂金会员\n100000000 管理', '', '一行一个组，格式为:最大积分 用户组名\"'),
(19, 1, 'extend', '放在页面头部<br/>head标签里面的<br/>meta或其它信息', 'textarea', 'head_meta', 'text', '', '', '示例:<br/>&lt;meta property=\"qc:admins\" content=\"331146677212163161xxxxxxx\" /&gt;<br/>&lt;meta name=\"cpalead-verification\" content=\"ymEun344mP9vt-B2idFRxxxxxxx\" /&gt;'),
(20, 2, 'extend', '放在页面底部的<br/>统计代码', 'textarea', 'analytics_code', 'text', '', '', '示例： 直接粘贴google 或 百度统计代码'),
(21, 3, 'extend', '底部链接', 'textarea', 'footer_links', 'text', '', '', '一行一个链接，格式： 描述 http://url<br />如：关于本站 http://simpleforum.org/t/1'),
(22, 4, 'extend', '时区', 'select', 'timezone', 'text', 'Asia/Shanghai', '', '修改时要特别注意！默认Asia/Shanghai'),
(23, 5, 'extend', '编辑器', 'select', 'editor', 'text', 'WysibbEditor', '{\"WysibbEditor\":\"Wysibb编辑器(BBCode)\"}', '普通论坛推荐Wysibb编辑器(BBCode)，技术类论坛推荐SimpleMarkdown编辑器。注意：换编辑器可能会使以前发的帖子格式混乱。'),
(24, 1, 'cache', '开启缓存', 'select', 'cache_enabled', 'integer', '0', '[\"0(关闭)\",\"1(开启)\"]', '默认0（不开启）'),
(25, 2, 'cache', '缓存时间(分)', 'text', 'cache_time', 'integer', '10', '', '默认10分'),
(26, 3, 'cache', '缓存类型', 'select', 'cache_type', 'text', 'file', '{\"file\":\"file\",\"apc\":\"apc\",\"memcache\":\"memcache\",\"memcached\":\"memcached\"}', '默认file'),
(27, 4, 'cache', '缓存服务器', 'textarea', 'cache_servers', 'text', '', '', '缓存类型设为MemCache时设置<br/>一个服务器一行，格式为：IP 端口 权重<br />示例：<br />127.0.0.1 11211 100<br />127.0.0.2 11211 200'),
(28, 1, 'auth', '开启第三方登录', 'select', 'auth_enabled', 'integer', '0', '[\"0(关闭)\",\"1(开启)\"]', ''),
(29, 2, 'auth', '第三方登录设定', 'textarea', 'auth_setting', 'text', '[]', '', ''),
(30, 1, 'other', '首页显示帖子数', 'text', 'index_pagesize', 'integer', '20', '', '默认20'),
(31, 2, 'other', '每页显示帖子数', 'text', 'list_pagesize', 'integer', '20', '', '默认20'),
(32, 3, 'other', '每页显示回复数', 'text', 'comment_pagesize', 'integer', '20', '', '默认20'),
(33, 4, 'other', '最热主题数', 'text', 'hot_topic_num', 'integer', '10', '', '默认10'),
(34, 5, 'other', '最热节点数', 'text', 'hot_node_num', 'integer', '20', '', '默认20'),
(35, 6, 'other', '可编辑时间(分)', 'text', 'edit_space', 'integer', '30', '', '默认30，主题贴和回复发表后可修改时间。'),
(36, 7, 'other', '发表主题间隔(秒)', 'text', 'topic_space', 'integer', '30', '', '默认30'),
(37, 8, 'other', '发表回复间隔(秒)', 'text', 'comment_space', 'integer', '20', '', '默认20'),
(38, 9, 'other', 'static目录自定义网址', 'text', 'alias_static', 'text', '', '', '自定义web/static目录的网址，可用于CDN。例：http://static.simpleforum.org'),
(39, 10, 'other', '头像目录自定义网址', 'text', 'alias_avatar', 'text', '', '', '自定义web/avatar目录的网址，可用于CDN。例：http://avatar.simpleforum.org'),
(40, 11, 'other', '附件目录自定义网址', 'text', 'alias_upload', 'text', '', '', '自定义web/upload目录的网址，可用于CDN。例：http://upload.simpleforum.org'),
(41, 1, 'mailer', 'SMTP服务器', 'text', 'mailer_host', 'text', '', '', ''),
(42, 2, 'mailer', 'SMTP端口', 'text', 'mailer_port', 'integer', '0', '', ''),
(43, 3, 'mailer', 'SMTP加密协议', 'text', 'mailer_encryption', 'text', '', '', '如ssl,tls等，不加密留空'),
(44, 4, 'mailer', 'SMTP验证邮箱', 'text', 'mailer_username', 'text', '', '', '请输入完整邮箱地址'),
(45, 5, 'mailer', 'SMTP验证密码', 'password', 'mailer_password', 'text', '', '', '验证邮箱的密码'),
(46, 1, 'upload', '头像上传', 'select', 'upload_avatar', 'text', 'local', '{\"local\":\"上传到网站所在空间\",\"remote\":\"上传到第三方空间\"}', '默认:上传到网站所在空间'),
(47, 2, 'upload', '附件上传', 'select', 'upload_file', 'text', 'disable', '{\"disable\":\"关闭上传\",\"local\":\"上传到网站所在空间\",\"remote\":\"上传到第三方空间\"}', '默认:网站空间'),
(48, 3, 'upload', '附件上传条件(注册时间)', 'text', 'upload_file_regday', 'integer', '30', '', '默认：30天'),
(49, 3, 'upload', '附件上传条件(主题数)', 'text', 'upload_file_topicnum', 'integer', '20', '', '默认：20'),
(50, 4, 'upload', '第三方空间', 'select', 'upload_remote', 'text', '', '[]', '');

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_siteinfo`
--

CREATE TABLE `g2ex_siteinfo` (
  `id` smallint(6) UNSIGNED NOT NULL,
  `nodes` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `users` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `topics` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `comments` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_siteinfo`
--

INSERT INTO `g2ex_siteinfo` (`id`, `nodes`, `users`, `topics`, `comments`) VALUES
(1, 11, 5, 10, 1);

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_tag`
--

CREATE TABLE `g2ex_tag` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL,
  `updated_at` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `topic_count` smallint(6) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_tag_topic`
--

CREATE TABLE `g2ex_tag_topic` (
  `id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL,
  `topic_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_token`
--

CREATE TABLE `g2ex_token` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL,
  `updated_at` int(10) UNSIGNED NOT NULL,
  `type` tinyint(1) UNSIGNED NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` mediumint(8) UNSIGNED NOT NULL,
  `expires` int(10) UNSIGNED NOT NULL,
  `token` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `ext` varchar(200) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_topic`
--

CREATE TABLE `g2ex_topic` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL,
  `updated_at` int(10) UNSIGNED NOT NULL,
  `replied_at` int(10) UNSIGNED NOT NULL,
  `node_id` smallint(6) UNSIGNED NOT NULL,
  `user_id` mediumint(8) UNSIGNED NOT NULL,
  `reply_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `alltop` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `top` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `invisible` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `closed` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `access_auth` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `comment_closed` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `comment_count` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `favorite_count` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `good` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `views` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `title` char(120) NOT NULL,
  `tags` char(60) NOT NULL DEFAULT '',
  `vote_count` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `star` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `editor` varchar(20) NOT NULL DEFAULT 'SmdEditor'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_topic`
--

INSERT INTO `g2ex_topic` (`id`, `created_at`, `updated_at`, `replied_at`, `node_id`, `user_id`, `reply_id`, `alltop`, `top`, `invisible`, `closed`, `access_auth`, `comment_closed`, `comment_count`, `favorite_count`, `good`, `views`, `title`, `tags`, `vote_count`, `star`, `editor`) VALUES
(2, 1530080781, 1530080781, 1530080781, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 304, 'ajax+jsonp+php 实现跨域交换数据', '', 0, 0, 'SmdEditor'),
(3, 1530082780, 1530082943, 1530082943, 1, 2, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 432, '程序员高手的软实力', '', 0, 0, 'SmdEditor'),
(4, 1530168757, 1530168757, 1530168757, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 343, 'php artisan key:generate', '', 0, 0, 'SmdEditor'),
(5, 1530170609, 1530170840, 1530170609, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 354, '解决 1071 Specified key was too long', '', 0, 0, 'SmdEditor'),
(6, 1530424808, 1530424808, 1530424808, 3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 350, 'git rm与git rm --cached', '', 0, 0, 'WysibbEditor'),
(7, 1530796703, 1530796703, 1530796703, 5, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 221, '关于网贷文章 当金融遇到互联网', '', 0, 0, 'SmdEditor'),
(8, 1531028948, 1531149743, 1531028948, 5, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 242, '哈哈哈哈', '', 0, 0, 'SmdEditor'),
(9, 1532322455, 1532322786, 1532322455, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 236, '数据安全大于一切，今天你把自己备份了吗？', '', 0, 0, 'WysibbEditor'),
(10, 1533365059, 1533365059, 1533365059, 4, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 449, 'NUXT（VUE SSR 服务端渲染）', '', 0, 0, 'SmdEditor'),
(11, 1535439394, 1535531032, 1535439394, 5, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 157, '哈哈哈哈', '', 0, 0, 'SmdEditor');

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_topic_content`
--

CREATE TABLE `g2ex_topic_content` (
  `topic_id` mediumint(8) UNSIGNED NOT NULL,
  `content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_topic_content`
--

INSERT INTO `g2ex_topic_content` (`topic_id`, `content`) VALUES
(2, '前端代码\r\n```\r\n<script src=\"js/jquery.min.js\" type=\"text/javascript\" charset=\"utf-8\"></script>  \r\n        <script type=\"text/javascript\">  \r\n            $(function(){  \r\n                  $.ajax({  \r\n                       url : \"http://192.168.1.130/mytest/mytest.php\",  \r\n                       dataType:\"jsonp\",  \r\n                       data:{  \r\n                           \"id\":\"123456\",  \r\n                           \"t\":1  \r\n                       },  \r\n                       type:\"post\",  \r\n                       jsonp:\"jsonpcallback\",  \r\n                       timeout: 5000,  \r\n                       success:function(data){  \r\n                           console.log(data);  \r\n                       },  \r\n                       error:function(XHR, textStatus, errorThrown){  \r\n                           console.log(\'error: \' + textStatus);  \r\n                           console.log(\'error: \' + errorThrown);  \r\n                       }  \r\n                  });  \r\n            });  \r\n  </script>  \r\n\r\n```\r\n\r\n后端代码\r\n```\r\n<?php  \r\n  \r\n$id = $_POST[\'id\'];  \r\n$t = $_POST[\'t\'];  \r\n  \r\n$jsonp = $_GET[\'jsonpcallback\'];//get接收jsonp自动生成的函数名  \r\n  \r\n$arr = array(  \r\n    \'id\' => $id,  \r\n    \'t\' => $t  \r\n);  \r\necho $jsonp.\'(\'. json_encode($arr). \')\'; //jsonp函数名包裹json数据  \r\n  \r\n  \r\n?>  \r\n```\r\n\r\n运行结果：\r\n![说明](https://img-blog.csdn.net/20161208134149765)'),
(3, '1、基础扎实\r\n \r\n技术知识决定一个人能做的技术的层次。基础的知识有计算机组成原理、计算机操作系统、网络原理、数据库原理、计算机图形学、编译原理、数据结构、离散数学、人工智能等等很高深的理论知识。\r\n \r\n在这些基础知识之上，就是软件开发语言、类库、框架，面向过程、面向对象、面向服务等编程思想，架构思想等等。\r\n \r\n这些知识不一定会影响你现在的工作，但一定会影响到你的格局，那格局肯定也会影响到你自身的发展。我碰到过有些理论很差的人，但技术在公司内也是有些影响力的，因此，他们对技术原理就很不屑，甚至为自己不懂太多理论而擅长实战而沾沾自喜。这些人会对那些懂理论，但动手能力一般的人显示出由内而外的鄙夷，但是他们却不知道那些既有基础知识，也有动手能力的高手做出的东西是怎样的。就像我本人，实在是想不通，那些技术天才是如何开发出一个数据库、操作系统这样的软件。因此，如果你已经发觉自己基础不够扎实，那么还是有空就修炼修炼自己的内功吧！\r\n \r\n2、文档与表达能力\r\n \r\n很多技术人员都写不了文档。不过，坦白的将，如果要获得更好的报酬，文档时绝对关键的因素。没有文档就没有沟通，就没有交易。有人提了，“文档是第一生产力”，我非常之赞同。文档的类型有很多，针对的对象也各不相同。不同的人，对文档的理解能力也是完全不一样的。因此，你的文档必须适应于你的目标。这个对于搞技术的人太难，他觉得还不如写代码来得快。\r\n \r\n表达能力决定了你所做的技术的影响范围，决定了你的影响力，决定你的威信。因此，也绝对的影响到你的报酬。因为这个能力而影响到你的报酬，你可能会心里觉得亏，但没有办法，这是硬伤，可不仅仅是我只是不擅长写文档，但我擅长与搞技术。如果哪一天，有一个擅长忽悠，技术不如你的人，爬到你的上面并且领导你，那也是该的。千万不要去怪别人擅长忽悠，而是要想办法来弥补自己的硬伤。\r\n \r\n3、积极的心态\r\n \r\n技术好的人，一般人都坏不到哪去。很简单的一句话，想要技术好，就要投入时间，有时间投入到技术，那么就没有时间投入到其它方面，特别是消极的坑蒙拐骗，因此，技术人员一般也都比较靠谱。\r\n \r\n积极的心态，不仅仅对于技术，对于生活也是如此。一旦有了积极的心态，那么菜鸟到高手的过程，仅仅是时间的问题！\r\n\r\n4、谦虚随和\r\n \r\n我们的客户都是一些大的企业，接触了很多各种类型的技术人员。你可以发现一个非常有趣的现象，那些懂得尊重别人、比较谦虚的人经过深入接触后，会发现他们的技术往往都很了不起；而那些说话刻薄无礼，觉得这个技术也不怎样，那个技术没什么了不起的，这个技术没有什么用，我自己的东西已经挺好的，这样的人水平、经验和见识一般都不怎样。软件的问题，并不是简简单单解决一个技术问题，从技术的角度上看，只要学会了使用技术，那么我们就已经掌握了技术，因此，单纯的技术是很简单的。相反的是，软件的协作开发、管理，软件的易用性，软件是否美观，这些东西才是最麻烦的，也往往是技术水平一般、经验短缺的程序员意识不到的东西。我曾经接触过不少一般的程序员，大体都是这一类，他们觉得软件太简单了，没有什么了不起的。对于什么思想，也不屑一顾，他们已经觉得自己掌握了很多真正的技术。\r\n'),
(4, 'Application key [base64:AKSdoVmvkCXVjQFxqWYKldURNSR1wobKubhY5faLB7Q=] set successfully.\r\n\r\n这个有什么用？'),
(5, '在安装laravel的项目时，\r\n\r\n在执行 php artisan migrate \r\n\r\n出现错误\r\n\r\nSyntax error or access violation: 1071 Specified key was too long; max key length is 1000 bytes\r\n\r\n![说明](https://www.uubd.net/upload/images/2018/0628/1518.png)\r\n\r\n```\r\n//兼容多种登录方式：user表对user_auths 一对多关系\r\n        Schema::create(\'jtz_user_auths\', function (Blueprint $table) {\r\n            $table->increments(\'id\');\r\n            $table->integer(\'user_id\')->index()->comment(\'用户id\');\r\n            $table->string(\'identity_type\',50)->default(\'\')->comment(\'登录类型（手机号phone 邮箱email 用户名username）或第三方应用名称（微信weixin 微博weibo 腾讯qq等）\');\r\n            $table->string(\'identifier\',200)->unique()->index()->comment(\'标识（手机号 邮箱 用户名或第三方应用的唯一标识）\');\r\n            $table->string(\'credential\',255)->default(\'\')->comment(\'密码凭证（站内的保存密码，站外的不保存或保存token）\');\r\n            $table->string(\'pre_modification\',255)->default(\'\')->comment(\'预修改密码\');\r\n            $table->tinyInteger(\'verified\')->default(0)->comment(\'是否已经验证激活\');\r\n            $table->timestamps();\r\n        });\r\n        DB::statement(\"ALTER TABLE `jtz_user_auths` comment \'用户验证表\'\");\r\n```\r\n\r\n\r\n解决方法：把 identifier 的长度从 255 改成 200\r\n\r\n有可能是数据库版本太低所致，升级数据库版本\r\n\r\n'),
(6, '当我们需要删除暂存区或分支上的文件, 同时工作区也不需要这个文件了, 可以使用\r\n\r\n﻿git rm file_path2\r\ngit commit -m \'delete somefile\'\r\ngit push\r\n\r\n当我们需要删除[code]暂存区[/code]或[code]分支[/code]上的文件, 但本地又需要使用, 只是不希望这个文件被版本控制, 可以使用\r\n﻿\r\n﻿git rm --cached file_path\r\ngit commit -m \'delete remote somefile\'\r\ngit push'),
(7, '\r\n　　“每天看一眼收益就挺开心的。”这是朱女士对余额宝的切身体会，“反正小钱闲着也是闲着。”\r\n\r\n　　许先生也关注互联网理财产品。他说：“以前总收到银行的广告短信，说是有5%、8%左右收益率的理财产品，现在看看好像网上买的理财产品收益率更高。”\r\n\r\n　　机密：作为互联网和金融的联姻产物，互联网理财产品其本质大多是基金，创新性体现在销售渠道、流动性、功能性等应用方面，内在的收益和风险都与传统产品相差不多。但这类产品在推广时往往会将本金安全问题淡化、将收益与活期存款比较，其实安全性仍比不上银行存款，收益率也会经常波动。\r\n\r\n　　低风险不等于无风险\r\n\r\n　　“百发”在前期宣传中被描述为一款年化收益率高达8%的无风险产品。事实上，略有投资常识的人立刻会产生疑问。\r\n\r\n　　首先，“百发”是一款与华夏基金合作的货币基金产品，以货币基金的平均收益水平来看，达到8%的年化收益率实属偶然事件;其次，该产品被描述为“无风险”，在同一市场中，无风险而利率能达到8%，难以想象有风险产品的收益率会达到怎样的水平。因此，“百发”虽在短时间内迅速吸引了大量眼球，但立刻引起了证监会的关注。随后，“百发”撤回了前期宣传，在产品正式首发中也没有出现“无风险”“年化收益率8%”的宣传语。\r\n\r\n　　机密：目前市场上推出的互联网理财产品数量不少，但类型单一，主要集中在货币市场基金和短期理财基金上。以风险属性来看，货币基金和短期理财基金都属于较低风险的品种。对投资者来说，既要对货币基金、理财基金的这种收益风险特点有所认知，也要意识到，产品的收益取决于市场环境，“低风险”和“无风险”是两个不同的概念。投资者还要注意互联网理财账户的安全问题，包括网站是否具有充分的安全防卫措施、认证手段是否充足等。投资者自身在使用时也需要保持良好的习惯，如不使用公共场所的网络进行操作、不轻易将自己的密码告诉他人及尽量采用复杂的认证手段等。\r\n\r\n　　想钓大鱼?换个鱼池吧\r\n\r\n　　虽然对基金并不了解，何女士还是把5万元钱都投进了一款互联网理财产品中。看着每天账户里的资金收益一点点地增长，何女士很开心：“又方便又有效，以后投得多了赚得会更多。”\r\n\r\n　　机密：像何女士这样的投资者其实不在少数，但这样的投资行为有着盲目跟风、方式单一的问题。一方面，投资者对所购产品是什么、如何盈利、收益为何波动均不了解，无法正确分辨其好坏、认识其风险;另一方面，把资金全部集中投向某一种理财产品，不能有效地防范投资风险，也难以获得理想的投资收益，是投资理财中的大忌。\r\n\r\n　　建议投资者对长期闲置的资金有一个配置的理念，选择互联网理财产品的同时，要不忘将高收益、高风险和低收益、保本稳健型的理财产品进行混搭。在投资期限上，也应尽量错开，区分好灵活短期的投资产品和较长期的投资产品。\r\n\r\n　　高收益都是凑出来的\r\n\r\n　　小胡是互联网理财达人，他认为理财保险产品的优势不少：一是产品的选择余地大，二是具有投资和保障两种功能，三是收益率显著地“高出一筹”。\r\n\r\n　　机密：如果我们认真研究一款收益率高出一筹的理财保险的话，就会发现其实际收益和大部分人所预期的有不小差异。作为一款万能险产品，保险公司给出的预期年化收益率最高为5.2%;在此基础上，投资者每投资1000元可获1200个集分宝，100个集分宝可抵扣1元钱，换算为收益率的话相当于1.2%的返还。因此，两项收益相累加，在实现预期年化收益率的前提下，这款投资期为一年的产品，其收益率能够达到6.4%。\r\n\r\n　　对于理财保险，产品销售时，万能险仅能够保障最低的收益率水平，大约为2.5%(年化)，其宣传的预期最高收益率只是一个“预期”的概念，结果出现偏差也属正常。\r\n\r\n　　忽悠你没商量\r\n\r\n　　投资灵活、收益高、门槛低，这些理财之“宝”正好满足了理财新人小连的需求。于是，他用自己活期账户的两万元购买了一款互联网理财产品，但他很快发现，理财产品的收益并不像自己期望的那样高，同时收益也不稳定。\r\n\r\n　　机密：互联网搭建起了新的理财平台，但投资者有必要厘清的是，自己所投资的产品究竟是什么，收益又是如何来确定的。像很多互联网理财产品的实质是与货币市场基金进行了“链接”，投资者购买了这些产品其实就是认购了某一支货币市场基金。因此，这些产品的收益率准确地来说，是指货币基金的7日年化收益率。'),
(8, '![说明](http://5b0988e595225.cdn.sohucs.com/images/20170916/f0d8254047a74d30aac4cfc402b36db2.jpeg)\r\n\r\n![说明](http://5b0988e595225.cdn.sohucs.com/images/20180709/d1ef2ed99b30407893cc8f69655ea98e.jpeg)\r\n\r\n![说明](http://5b0988e595225.cdn.sohucs.com/images/20180709/503eafe2220e4b7e9726be90233ba9a4.jpeg)\r\n\r\n![说明](http://5b0988e595225.cdn.sohucs.com/images/20180709/44265de32b234e84bec4b9e5ee47ad0f.jpeg)\r\n\r\n![说明](http://5b0988e595225.cdn.sohucs.com/images/20180709/d97b55196c1446908b757ce819227723.jpeg)\r\n\r\n![说明](http://5b0988e595225.cdn.sohucs.com/images/20180709/aa6786c43d8d4887a99c80f9c5307dc5.jpeg)'),
(9, '假设你是一位女性，你有一位男朋友，于此同时你和另外一位男生暧昧不清，比朋友好，又不是恋人。你随时可以甩了现任男友，另外一位马上就能补上。这是冷备份。\r\n\r\n假设你是一位女性，同时和两位男性在交往，两位都是你男朋友。并且他们还互不干涉，独立运行。这就是双机热备份。\r\n\r\n假设你是一位女性，不安于男朋友给你的安全感。在遥远的男友未知的地方，和一位男生保持着联系，你告诉他你没有男朋友，你现在处于纠结期，一旦你和你男朋友分开了，你马上可以把自己感情转移到异地男人那里去。这是异地容灾备份。\r\n\r\n假设你是一位女性，有一位男朋友，你又付了钱给一家婚姻介绍所，让他帮你留意好的资源，一旦你和你这位男朋友分开，婚姻介绍所马上给你安排资源，你感情不间断运行，这是云备份。。。。\r\n\r\n数据安全大于一切，今天你把自己备份了吗？\r\n\r\n假设你是一位女性，你怀疑男朋友对你的忠诚，在某宝购买了一个测试忠诚度的服务。这是灾难演练。友情提醒，在没有备份的情况下，切忌进行灾难演练，说不好会让你数据血本无归。。\r\n\r\n假设你是一位女性，你有一位好到不能在好的闺蜜，好到你们可以共享一个男朋友，这是NAS。\r\n\r\n假设你是一位女性，你男朋友活太好，你一个人根本hold不住，必须要姐妹帮忙才能稳住他。这是负载均衡，QOS。\r\n\r\n假设你是一位女性，和A吃饭和B逛街和C打炮。合起来是一个完整的男朋友。这。。这是超算集群。。。建议主频不高的女性不要这样做。会直接死机的。。\r\n\r\n\r\n备份是为了更好地运行，所以再给大家普及一点运维知识\r\n\r\n假设你是一位女性，你的男友沉迷游戏经常不接电话无故宕机，所以当你们约好下午逛街以后你要时不时的打个电话询问，看看他是不是还能正常提供服务，这叫心跳检测\r\n\r\n假设你是一位女性，你想去逛街而你的男友A在打游戏不接电话，于是乎你把逛街的请求发给了替补男友B，从而保障服务不间断运行，这叫故障切换\r\n\r\n假设你是一位女性，你有很多需要男朋友完成的事情，于是乎你跟A逛街旅游吃饭不可描述，而B只能陪你逛街，不能拥有全部男朋友的权利，这叫主从配置 master-slave\r\n\r\n假设你是一位女性，你的需求太强烈以至于你的男友根本吃不消，于是呼你找了两个男朋友，一三五单号，二四六双号限行，从而减少一个男朋友所面临的压力，这叫负载均衡\r\n\r\n假设你是一位女性并且有多个男朋友，配合心跳检测与故障切换和负载均衡将会达到极致的体验，这叫集群LVS，注意，当需求单机可以处理的情况下不建议启用集群，会造成大量资源闲置，提高维护成本\r\n\r\n假设你是一位女性，你的需求越来越高导致一个男朋友集群已经处理不了了，于是乎你又新增了另外几个，这叫多集群，横行扩容，简称multi-cluster grid \r\n\r\n假设你是一位女性，你的男朋友身体瘦弱从而无法满足需求，于是乎你买了很多大补产品帮你男朋友升级，从而提高单机容量，这叫纵向扩容，切记，纵向扩容的成本会越来越高而效果越来越不明显\r\n\r\n假设你是一位女性，你跟男友经常出去游玩，情到深处想做点什么的时候却苦于没有tt，要去超市购买，于是乎你在你们经常去的地方都放置了tt，从而大幅度降低等待时间，这叫CDN\r\n\r\n假设你是一位女性,你的男朋友英俊潇洒风流倜傥财大气粗对你唯一,于是乎你遭到了女性B的敌视，B会以朋友名义在周末请求你男朋友修电脑,修冰箱,占用男朋友大量时间,造成男朋友无法为你服务,这叫拒绝服务攻击,简称DOS\r\n\r\n假设你是一位女性,你因男朋友被一位女性敌视,但是你男朋友的处理能力十分强大,处理速度已经高于她的请求速度,于是她雇佣了一票女性来轮流麻烦你的男朋友,这叫分布式拒绝服务攻击,简称DDOS\r\n\r\n假设你是一位女性,你发现男朋友总是在处理一些无关紧要的其它请求,于是呼你给男朋友了一个白名单,要求他只处理白名单内的请求,而拒绝其它身份不明的人的要求,这叫访问控制,也叫会话跟踪\r\n\r\n假设你是一位女性,你发现采取上述措施以后男朋友的处理请求并没有减少很多,于是你经过调查发现,有人伪造你的微信头像 昵称来向你的男朋友发起请求,这叫跨站点请求伪造 简称CSRF\r\n\r\n假设你是一位女性,你收到了一份快递,于是你要求男朋友给你取快递,当你拿到快递以后发现有人给你邮寄了一封通篇辱骂的信件,这叫跨站点脚本攻击 简称XSS,请注意,对方完全可以给你邮寄微型窃听器来窃听你的隐私\r\n\r\n假设你是一位女性,为了应对威胁,你要求你的男朋友,邮寄给你的邮件必须检查,这叫数据校验与过滤\r\n\r\n假设你是一位女性,你的男朋友太优秀而造人窥视,于是乎它们研究了一下你的男朋友,稍微修改了一点点生产出一个男朋友B 与你的男朋友百分制99相似,这不叫剽窃,这叫逆向工程,比如男朋友外挂\r\n\r\n假设你是一位女性，你要求你的男朋友坚持十分钟，然后十五分钟继而二十分钟以测试你男朋友的极限在哪里，这叫压力测试\r\n\r\n压力测试的目的是查看男朋友是否可以处理需求从而决定是否启用男朋友集群或提升男朋友处理能力，不要对线上运行的男朋友做压力测试，可能会造成宕机的后果，会血本无归的\r\n\r\n假设你是一位女性，为了保证你男朋友的正常运行，于是乎你每天查看他的微信微博等社交资料来寻找可能产生问题的线索，这叫数据分析\r\n\r\n假设你是一位女性，你的男朋友属于社交活跃选手，每天的微博知乎微信生产了大量信息，你发现自己的分析速度远远低于他生的速度，于是乎你找来你的闺蜜一起分析，这叫并行计算\r\n\r\n假设你是一位女性，你的男朋友太能折腾处处留情产生了天量的待处理信息，你和你的闺蜜们已经累趴也没赶上他创造的速度，于是你付费在知乎上找了20个小伙伴帮你一起分析，这叫云计算\r\n\r\n假设你是一位女性，在使用云计算后获得了大量整理好的男朋友数据，这些数据如：\r\n地点       活跃时间段       活跃次数\r\n如家       xxxx            123次\r\n汉庭       xxxx             45次\r\n...\r\n这叫数据统计\r\n\r\n假设你是一位女性，你在得到男朋友经常出没的地点后，根据酒店，敏感时间段等信息确定男朋友因该是出轨了，这叫数据挖掘\r\n\r\n假设你是一位女性，在分析男友的数据后，得知他下午又要出去开房，于是乎你在他准备出门前给他发了个短信，问他有没有带tt，没有的话可以在我这里买，这叫精准推送，需要配合数据挖掘\r\n\r\n假如你是一位女性，你的男朋友总该出去浪而各种出问题，于是乎你租了间屋子并准备好了所有需要的东西并告诉他，以后不用找酒店了，直接来我这屋子吧，什么都准备好了，这叫容器\r\n\r\n假如你是一位女性，而你的男朋友是个码农，晚上不睡觉跟大家深入浅出的科普热备、冷备、云备份，那么这些备份你全都用得着\r\n\r\n\r\n假如你是一位女性，你每天都要和男朋友打通一次接口，采集数据。\r\n你的男朋友用来连接你和他的工具，叫做接口“机”，你采集到的数据叫做“流”数据。\r\n你一天24小时不停地采，这叫实时数据采集。你决定开发新的接口来和男朋友交流，这叫虚拟化。\r\n你决定从不同的男友身上采集数据，你就是大数据中心。\r\n有一天你决定生一个宝宝，这叫大数据应用。宝宝生下来不知道是谁的，这叫大数据脱敏。\r\n但是从宝宝外观来看，黑色皮肤金色头发，这叫数据融合跨域建模。\r\n你决定把这个宝宝拿来展览收点门票，这叫大数据变现'),
(10, 'Server Side Rendering（服务端渲染）\r\n\r\nSSR 目的是为了解决单页面应用的 SEO 的问题，对于一般网站影响不大，但是对于论坛类，内容类网站来说是致命的，搜索引擎无法抓取页面相关内容，也就是用户搜不到此网站的相关信息。\r\n\r\n原理\r\n将 html 在服务端渲染，合成完整的 html 文件再输出到浏览器。\r\n\r\n适用场景\r\n客户端的网络比较慢\r\n客户端运行在老的或者直接没有 JavaScript 引擎上\r\nNUXT\r\n作用就是在 node.js 上进一步封装，然后省去我们搭建服务端环境的步骤，只需要遵循这个库的一些规则就能轻松实现 SSR。\r\n\r\n可以作为一个 Node.js 应用跑在服务器上，也可以把整站直接编译为静态 HTML。另外这个框架支持自动生成路由，用来写展示型的页面是非常不错的选择。\r\n\r\nNUXT 能为我们做什么\r\n无需再为了路由划分而烦恼，你只需要按照对应的文件夹层级创建 .vue 文件就行\r\n无需考虑数据传输问题，nuxt 会在模板输出之前异步请求数据（需要引入 axios 库），而且对 vuex 有进一步的封装\r\n内置了 webpack，省去了配置 webpack 的步骤，nuxt 会根据配置打包对应的文件\r\n安装流程\r\n\r\n$ npm install -g vue-cli\r\n\r\n$ vue init nuxt/starter <project-name>\r\n$ cd <project-name>\r\n$ npm install\r\n\r\n$ npm run dev\r\n\r\nNuxt.js 会监听 pages 目录下的改变，添加新 page 的时候不需要重启服务\r\n\r\nNext.js\r\n来自Zeit的团队在React的基础和组件模型上构建了Next.js，同时还提供了一个关键扩展：通过使用名为getInitialProps()的组件生命周期钩子方法，框架能够在服务器上进行初始渲染，如果需要的话，还可以在客户端继续进行渲染。不过这个高级特性是一个很小却功能强大的框架所额外提供的。\r\n\r\nNext提供了非常丰富的生态环境，特别是它的example，包含了多种情况下的源码，让学习者很容易搭建起一个多功能的Next框架，客户端有的东西，服务端基本都有。\r\n\r\nwebpack的各项配置，Next集成了webpack的很多配置，热更新是必备品，还支持提供next.config.js的方式导入自己定义的配置。\r\n你可以使用less、scss、style-in-Component、css等各种样式写法。\r\n支持redux、redux-saga、或者不用。\r\n各种图片的支持都包含在webpack中了。\r\n支持自定义的babelrc配置。\r\n对于react的版本的支持也在维护者的维护中不断更新。\r\n支持preact。\r\n简单易用，就跟写 PHP 一样一个文件一个页面了，但缺点也很明显，其实它是通过改变正常 React + webpack 的代码书写习惯来绕过前后端同构的坑，所以也引入了一些新的问题：\r\n\r\n图片等静态文件只能放在 static 目录下，不能通过 require 来引入，也就是没办法通过 webpack 来进行模块化管理，如果各个组件有自身依赖的图片，也只能一股脑放 static 里，也很难实现版本管理控制浏览器缓存。\r\n样式同样也没办法通过 webpack 进行模块化管理，只能通过 style 标签嵌入或直接内联。\r\n简单地说，很适合快速搭建简单站点，但自由度不高，且带样式或图片的 React 组件无法直接使用，个人看法是一个用自由度和通用性来换取易用性的框架。\r\n\r\n其他方法\r\nGoogle 可以正常爬取和渲染一个纯 js 动态生成的网站，上传 sitemap 就可以了。\r\n\r\n直接生成静态页面由 CDN 分发。有些新技术还可以在 static gen 同时支持 pwa，比如 gatsbyjs。\r\n\r\n掘金是未登录用户使用 SSR，不错的思路。\r\n\r\n要分清楚什么时候用 mvvm，mvvm 其实就是 modelview 非常方便定义页面的各种逻辑和改变页面数据，如果是传统的网站，前端没啥逻辑，就没有必要上 mvvm\r\n'),
(11, '呵呵呵呵');

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_user`
--

CREATE TABLE `g2ex_user` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL,
  `updated_at` int(10) UNSIGNED NOT NULL,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT '8',
  `role` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `score` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `username` char(16) NOT NULL,
  `email` char(50) NOT NULL,
  `password_hash` char(80) NOT NULL,
  `auth_key` char(32) NOT NULL,
  `avatar` char(255) NOT NULL DEFAULT 'avatar/0_{size}.png',
  `comment` char(20) NOT NULL DEFAULT '',
  `reg` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_user`
--

INSERT INTO `g2ex_user` (`id`, `created_at`, `updated_at`, `status`, `role`, `score`, `username`, `email`, `password_hash`, `auth_key`, `avatar`, `comment`, `reg`) VALUES
(1, 1528268383, 1533365059, 10, 10, 10000924, 'admin', '670799251@qq.com', '$2y$13$JbQaE2pb6W2HyG/6Ap/0nu8zecWDczEVudqRumZBHkNug1MsKLhTu', 'UOAC9PNF9wQ2NNTDIesQkubPEinIfi0b', 'avatar/h/s/1_{size}.jpg?m=1530080943', '', 1),
(2, 1530082386, 1530455153, 10, 0, 1142, '一到六', '123456@163.com', '$2y$13$9ywo79bJyWx.URzCBAVxTO2c03HKDK4e/kNBvk2oLuaH8bVwdNkMe', 'ga55-LN1qbU8Fgt84W4mAaVYVy1tLUdu', 'avatar/j/b/2_{size}.jpg?m=1530082470', '', 1),
(3, 1531378032, 1531378032, 10, 0, 100, '大庆商江', 'dqddsj@163.com', '$2y$13$RJky7UuVCme7Yf1TcLpXt.lGO.SBoYEy5iCP8u1ipwVUe9lCXbVgC', 'ZUh2-V6x88_bIYQiC4mhwj41r9VeNdbC', 'avatar/0_{size}.png', '', 0),
(4, 1531831526, 0, 8, 0, 100, '李皮皮', '8796@6770.com', '', 'a907e8e4-b79a-f7da-3794-199e2fd4', 'avatar/h/s/1_{size}.jpg?m=1530080943', '', 1),
(5, 1531831987, 0, 8, 0, 100, '精', '6550@9715.com', '', '314e1a75-42a2-a00a-3feb-4139c5c8', 'avatar/h/s/1_{size}.jpg?m=1530080943', '', 1),
(6, 1532232814, 0, 8, 0, 100, '王小米', '5108@7775.com', '', '3849b603-3ce0-813d-ecb5-8d5c62aa', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLibFM0Fujy2gP0dJ1E3Xfuf9WPl2ic3LI1sViaq14EzicgXnRNoBZicPFZJ2Kel2rg9zm3N2l45SK0heg/132', '', 1),
(7, 1532315198, 0, 8, 0, 100, 'hihihihi', '4780@1303.com', '', 'c4ffb631-9363-438c-4595-7a042c23', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKibwsHWwHRYyTiatzwNgxVY1uIKMUY9IlbTsClicujr4cPrHElzNOkHzAR4yBFwakhnq1My51dONVZA/132', '', 1),
(8, 1532341137, 0, 8, 0, 100, 'Justdoit', '2539@2507.com', '', 'c0aad3d1-0e83-8515-85ad-12580a70', 'https://wx.qlogo.cn/mmopen/vi_32/DYAIOgq83erMOgIs57YfSEqpU7InVC3yR9R9PANqIMcODZPvItwovYSEl2FZqMBalI0AhKyicOWfyTnf3LjfPqQ/132', '', 1),
(9, 1533360895, 0, 8, 0, 100, '晓风残月', '1329@2919.com', '', '42e70c82-a110-44b5-4d71-0cf97d02', 'https://wx.qlogo.cn/mmopen/vi_32/3xB6zWuiaG2x7zXrWnIPXkRFm4MxEgA1vAfv7fq2QfRJJL6nkYef9ZMLzgddSuwJjz58PhVHEuZAD6FpxNJUBdA/132', '', 1),
(10, 1535439375, 1535439394, 10, 0, 80, 'peizi999', 'zza093@163.com', '$2y$13$YM5gl5Q4Ry0tI.7exoq2Au67HCF4XJgaIOgqTYmnXaSx4o1kLB.ha', 'KkGfbSWswe_CU28acO_5HbyEHxnFbPXB', 'avatar/0_{size}.png', '', 0),
(11, 1545533602, 1545533602, 10, 0, 100, 'WarnerMag', 'nustadeleberit@gmail.com', '$2y$13$CbnP5ERGvq.t6tMDyqUQuuZkuoehpm9Fz804fVvG3MVROwDNTP4ra', 'pxnNvExn87-o0mjQJykxTcBXy9pqczFb', 'avatar/0_{size}.png', '', 0);

-- --------------------------------------------------------

--
-- 表的结构 `g2ex_user_info`
--

CREATE TABLE `g2ex_user_info` (
  `user_id` mediumint(8) UNSIGNED NOT NULL,
  `last_login_at` int(10) UNSIGNED NOT NULL,
  `last_login_ip` int(10) UNSIGNED NOT NULL,
  `reg_ip` int(10) UNSIGNED NOT NULL,
  `topic_count` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `comment_count` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `favorite_count` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `favorite_node_count` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `favorite_topic_count` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `favorite_user_count` smallint(6) UNSIGNED NOT NULL DEFAULT '0',
  `website` varchar(100) NOT NULL DEFAULT '',
  `about` varchar(255) NOT NULL DEFAULT '',
  `location` varchar(100) NOT NULL DEFAULT '',
  `tagline` varchar(100) NOT NULL DEFAULT '',
  `topic_close` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `comment_close` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `top_close` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `css_close` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `email_close` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `mynodes` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `mycss` text NOT NULL,
  `qq` varchar(15) NOT NULL DEFAULT '',
  `mobile` varchar(11) NOT NULL,
  `favorite_vote_count` smallint(6) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `g2ex_user_info`
--

INSERT INTO `g2ex_user_info` (`user_id`, `last_login_at`, `last_login_ip`, `reg_ip`, `topic_count`, `comment_count`, `favorite_count`, `favorite_node_count`, `favorite_topic_count`, `favorite_user_count`, `website`, `about`, `location`, `tagline`, `topic_close`, `comment_close`, `top_close`, `css_close`, `email_close`, `mynodes`, `mycss`, `qq`, `mobile`, `favorite_vote_count`) VALUES
(1, 1535531001, 1039280680, 1900144371, 8, 1, 0, 0, 1, 0, '', '', '', '', 0, 0, 0, 1, 1, 0, '', '', '', 0),
(2, 1530425632, 992668917, 992566512, 1, 0, 0, 0, 0, 0, '', '', '', '', 0, 0, 0, 1, 1, 0, '', '', '', 0),
(3, 1531378032, 1974720148, 1974720148, 0, 0, 0, 0, 0, 0, '', '', '', '', 0, 0, 0, 1, 1, 0, '', '', '', 0),
(4, 1531831527, 113, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', 0, 0, 0, 1, 1, 0, '', '', '', 0),
(5, 1531831987, 116, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', 0, 0, 0, 1, 1, 0, '', '', '', 0),
(6, 1532232814, 183, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', 0, 0, 0, 1, 1, 0, '', '', '', 0),
(7, 1532315198, 183, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', 0, 0, 0, 1, 1, 0, '', '', '', 0),
(8, 1532341137, 116, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', 0, 0, 0, 1, 1, 0, '', '', '', 0),
(9, 1533360895, 58, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', 0, 0, 0, 1, 1, 0, '', '', '', 0),
(10, 1535439375, 986737834, 986737834, 1, 0, 0, 0, 0, 0, '', '', '', '', 0, 0, 0, 1, 1, 0, '', '', '', 0),
(11, 1545533602, 3000350775, 3000350775, 0, 0, 0, 0, 0, 0, '', '', '', '', 0, 0, 0, 1, 1, 0, '', '', '', 0);

--
-- 转储表的索引
--

--
-- 表的索引 `g2ex_ad`
--
ALTER TABLE `g2ex_ad`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `adkey` (`location`,`node_id`,`expires`,`sortid`,`id`);

--
-- 表的索引 `g2ex_auth`
--
ALTER TABLE `g2ex_auth`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_source` (`user_id`,`source`),
  ADD UNIQUE KEY `source_source_id` (`source`,`source_id`);

--
-- 表的索引 `g2ex_comment`
--
ALTER TABLE `g2ex_comment`
  ADD PRIMARY KEY (`topic_id`,`position`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `user_id` (`user_id`,`id`),
  ADD KEY `topic_updated` (`topic_id`,`updated_at`);

--
-- 表的索引 `g2ex_commentid`
--
ALTER TABLE `g2ex_commentid`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `g2ex_favorite`
--
ALTER TABLE `g2ex_favorite`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `source_type_target` (`source_id`,`type`,`target_id`),
  ADD KEY `type_target` (`type`,`target_id`);

--
-- 表的索引 `g2ex_history`
--
ALTER TABLE `g2ex_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_type_id` (`user_id`,`type`,`id`);

--
-- 表的索引 `g2ex_link`
--
ALTER TABLE `g2ex_link`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sort_id` (`sortid`,`id`);

--
-- 表的索引 `g2ex_msg`
--
ALTER TABLE `g2ex_msg`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `g2ex_navi`
--
ALTER TABLE `g2ex_navi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`type`,`name`),
  ADD UNIQUE KEY `ename` (`type`,`ename`),
  ADD KEY `type_sort` (`type`,`sortid`);

--
-- 表的索引 `g2ex_navi_node`
--
ALTER TABLE `g2ex_navi_node`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `navi_node` (`navi_id`,`node_id`),
  ADD KEY `navi_node_sort` (`navi_id`,`node_id`,`sortid`),
  ADD KEY `navi_node_visible_sort` (`navi_id`,`node_id`,`visible`,`sortid`);

--
-- 表的索引 `g2ex_node`
--
ALTER TABLE `g2ex_node`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `ename` (`ename`),
  ADD KEY `topic_id` (`topic_count`,`id`),
  ADD KEY `invisible` (`invisible`,`id`);

--
-- 表的索引 `g2ex_notice`
--
ALTER TABLE `g2ex_notice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target_status_id` (`target_id`,`status`,`id`);

--
-- 表的索引 `g2ex_page`
--
ALTER TABLE `g2ex_page`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `adkey` (`sortid`,`id`);

--
-- 表的索引 `g2ex_plugin`
--
ALTER TABLE `g2ex_plugin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pid` (`pid`);

--
-- 表的索引 `g2ex_setting`
--
ALTER TABLE `g2ex_setting`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`),
  ADD KEY `block_sort_id` (`block`,`sortid`,`id`);

--
-- 表的索引 `g2ex_siteinfo`
--
ALTER TABLE `g2ex_siteinfo`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `g2ex_tag`
--
ALTER TABLE `g2ex_tag`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `updated` (`updated_at`,`id`),
  ADD KEY `topic_count` (`topic_count`,`id`);

--
-- 表的索引 `g2ex_tag_topic`
--
ALTER TABLE `g2ex_tag_topic`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tag_topic` (`tag_id`,`topic_id`);

--
-- 表的索引 `g2ex_token`
--
ALTER TABLE `g2ex_token`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `user_type_expires` (`user_id`,`type`,`expires`);

--
-- 表的索引 `g2ex_topic`
--
ALTER TABLE `g2ex_topic`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alllist` (`node_id`,`alltop`,`replied_at`,`id`),
  ADD KEY `nodelist` (`node_id`,`top`,`replied_at`,`id`),
  ADD KEY `hottopics` (`node_id`,`created_at`,`comment_count`,`replied_at`),
  ADD KEY `updated` (`updated_at`),
  ADD KEY `node_updated` (`node_id`,`updated_at`),
  ADD KEY `allcount` (`node_id`,`id`),
  ADD KEY `user_id` (`user_id`,`id`);

--
-- 表的索引 `g2ex_topic_content`
--
ALTER TABLE `g2ex_topic_content`
  ADD PRIMARY KEY (`topic_id`);

--
-- 表的索引 `g2ex_user`
--
ALTER TABLE `g2ex_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `status_id` (`status`,`id`);

--
-- 表的索引 `g2ex_user_info`
--
ALTER TABLE `g2ex_user_info`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `mobile` (`mobile`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `g2ex_ad`
--
ALTER TABLE `g2ex_ad`
  MODIFY `id` smallint(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `g2ex_auth`
--
ALTER TABLE `g2ex_auth`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- 使用表AUTO_INCREMENT `g2ex_comment`
--
ALTER TABLE `g2ex_comment`
  MODIFY `position` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `g2ex_commentid`
--
ALTER TABLE `g2ex_commentid`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `g2ex_favorite`
--
ALTER TABLE `g2ex_favorite`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `g2ex_history`
--
ALTER TABLE `g2ex_history`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- 使用表AUTO_INCREMENT `g2ex_link`
--
ALTER TABLE `g2ex_link`
  MODIFY `id` smallint(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `g2ex_msg`
--
ALTER TABLE `g2ex_msg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- 使用表AUTO_INCREMENT `g2ex_navi`
--
ALTER TABLE `g2ex_navi`
  MODIFY `id` smallint(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `g2ex_navi_node`
--
ALTER TABLE `g2ex_navi_node`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `g2ex_node`
--
ALTER TABLE `g2ex_node`
  MODIFY `id` smallint(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- 使用表AUTO_INCREMENT `g2ex_notice`
--
ALTER TABLE `g2ex_notice`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用表AUTO_INCREMENT `g2ex_page`
--
ALTER TABLE `g2ex_page`
  MODIFY `id` smallint(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `g2ex_plugin`
--
ALTER TABLE `g2ex_plugin`
  MODIFY `id` smallint(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- 使用表AUTO_INCREMENT `g2ex_setting`
--
ALTER TABLE `g2ex_setting`
  MODIFY `id` smallint(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- 使用表AUTO_INCREMENT `g2ex_siteinfo`
--
ALTER TABLE `g2ex_siteinfo`
  MODIFY `id` smallint(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `g2ex_tag`
--
ALTER TABLE `g2ex_tag`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `g2ex_tag_topic`
--
ALTER TABLE `g2ex_tag_topic`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `g2ex_token`
--
ALTER TABLE `g2ex_token`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `g2ex_topic`
--
ALTER TABLE `g2ex_topic`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- 使用表AUTO_INCREMENT `g2ex_topic_content`
--
ALTER TABLE `g2ex_topic_content`
  MODIFY `topic_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- 使用表AUTO_INCREMENT `g2ex_user`
--
ALTER TABLE `g2ex_user`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- 使用表AUTO_INCREMENT `g2ex_user_info`
--
ALTER TABLE `g2ex_user_info`
  MODIFY `user_id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
